package homework;

public class HW2 {

    public static void main (String[]args) {

        int k=1;
        int l=2;
        int m=3;
        int devKL=1/2;
        int devKM=1/3;
        int devLM=2/3;
        int devMK=3/1;
        int apple=40;
        int student=6;
        int devAppleStudent=apple/student;
        int sumKLM=1+2+3;
        int sumLKM=2+1+3;

        System.out.println(k);
        System.out.println(l);
        System.out.println(m);

        System.out.println(""+k+","+l+","+m);

        System.out.println("k="+k);
        System.out.println("l="+l);
        System.out.println("m="+m);

        System.out.println("Sum of k and l="+(k+l));
        System.out.println("k * m="+(k * m));
        System.out.println("Разность переменных l и m="+(l-m));

        System.out.println("Результат деления k на l ="+devKL+ ","+"а остаток от деления  ="+(k%l));
        System.out.println("Результат деления k на m ="+devKM+ ","+"а остаток от деления  ="+(k%m));
        System.out.println("Результат деления l на m ="+devLM+ ","+"а остаток от деления  ="+(l%m));
        System.out.println("Результат деления m на k ="+devMK+ ","+"а остаток от деления  ="+(m%k));

        System.out.println("Если " +apple+ " яблок поделить на "+student+" учеников, то каждый ученик получит по "+devAppleStudent+" яблок(a), и "+(apple%student)+" яблок(а) останется учителю. ");

        sumKLM = sumKLM--;
        m = m++;
        System.out.println("sumKLM-- + k, l, m++ = "+(sumKLM+(k+l+m)));

        m = m++;
        System.out.println("m++ - sumLKM = "+(m-sumLKM));




    }
}

